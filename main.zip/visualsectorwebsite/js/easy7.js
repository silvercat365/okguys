var priceCalculator = document.getElementById('quote-calc');
priceCalculator.onchange = calculatesubtotal;
priceCalculator.onchange();
function calculatesubtotal() {
	var beds = Number(document.getElementById('beds').value) || 0;
	var baths = Number(document.getElementById('baths').value) || 0;
	var extras = 0;
	var move = 0;
	var fridge = 0;
	var oven = 0;
	var dishes = 0;
	var laundry = 0;
		if ( $( "#move-col" ).hasClass( "on" ) ) {  move = 149; }
		if ( $( "#fridge-col" ).hasClass( "on" ) ) { fridge = 200; }
		if ( $( "#oven-col" ).hasClass( "on" ) ) { oven = 150; }
		if ( $( "#dish-col" ).hasClass( "on" ) ) { dishes = 20; }
		if ( $( "#laundry-col" ).hasClass( "on" ) ) { laundry = 55; }
	extras = move + fridge + oven + dishes + laundry;
	var discount = 1;
		if ( $( "#col-once-off" ).hasClass( "on" ) ) {
			discount = 1;
		} else if ( $( "#col-weekly" ).hasClass( "on" ) ) {
			discount = 1.1;
		} else if ( $( "#col-fortnightly" ).hasClass( "on" ) ) {
			discount = 1.01;
		} else if ( $( "#col-monthly" ).hasClass( "on" ) ) {
			discount = 0.06;
		}
	var subtotal = (beds + (baths * 110) + extras) * discount;
	document.getElementById("total").innerHTML = "$" + subtotal.toFixed(2);
}

$('#move-col').on('click', function() {
	var $$ = $(this)
	if (!$$.is('.on')) {
		$$.addClass('on');
		// run function to remove all other 'ons' from other oftens
		document.getElementById("move").src = "/images/quickwhite.png";
	} else {
		$$.removeClass('on');
		document.getElementById("move").src = "/images/quick.png";
	}
	calculatesubtotal();
})
$('#fridge-col').on('click', function() {
	var $$ = $(this)
	if (!$$.is('.on')) {
		$$.addClass('on');
		// run function to remove all other 'ons' from other oftens
		document.getElementById("fridge").src = "/images/livewhite.png";
	} else {
		$$.removeClass('on');
		document.getElementById("fridge").src = "/images/live.png";
	}
	calculatesubtotal();
})
$('#oven-col').on('click', function() {
	var $$ = $(this)
	if (!$$.is('.on')) {
		$$.addClass('on');
		// run function to remove all other 'ons' from other oftens
		document.getElementById("oven").src = "/images/emailwhite.png";
	} else {
		$$.removeClass('on');
		document.getElementById("oven").src = "/images/email.png";
	}
	calculatesubtotal();
})
$('#dish-col').on('click', function() {
	var $$ = $(this)
	if (!$$.is('.on')) {
		$$.addClass('on');
		// run function to remove all other 'ons' from other oftens
		document.getElementById("dish").src = "/images/servergreenwhite.png";
	} else {
		$$.removeClass('on');
		document.getElementById("dish").src = "/images/servergreen.png";
	}
	calculatesubtotal();
})
$('#laundry-col').on('click', function() {
	var $$ = $(this)
	if (!$$.is('.on')) {
		$$.addClass('on');
		// run function to remove all other 'ons' from other oftens
		document.getElementById("laundry").src = "/images/serverbluewhite.png";
	} else {
		$$.removeClass('on');
		document.getElementById("laundry").src = "/images/serverblue.png";
	}
	calculatesubtotal();
})

$('#col-once-off').on('click', function() {
	var $$ = $(this)
	if (!$$.is('.on')) {
		$$.addClass('on');
		onlyOne('onceOff');
		// run function to remove all other 'ons' from other oftens
		document.getElementById("once-off").src = "https://www.moplovers.com.au/wp-content/uploads/2017/02/Onceoff-on.png";
	}
	calculatesubtotal();
})
$('#col-weekly').on('click', function() {
	var $$ = $(this)
	if (!$$.is('.on')) {
		$$.addClass('on');
		onlyOne('weekly');
		document.getElementById("weekly").src = "https://www.moplovers.com.au/wp-content/uploads/2017/02/Weekly-on.png";
	}
	calculatesubtotal();
})
$('#col-fortnightly').on('click', function() {
	var $$ = $(this)
	if (!$$.is('.on')) {
		$$.addClass('on');
		onlyOne('fortnightly');
		document.getElementById("fortnightly").src = "https://www.moplovers.com.au/wp-content/uploads/2017/02/Fortnightly-on.png";
	} 
	calculatesubtotal();
})
$('#col-monthly').on('click', function() {
	var $$ = $(this)
	if (!$$.is('.on')) {
		$$.addClass('on');
		onlyOne('monthly');
		document.getElementById("monthly").src = "https://www.moplovers.com.au/wp-content/uploads/2017/02/Monthly-on.png";
	} 
	calculatesubtotal();
})

function onlyOne(id) {
	switch (id) {
case 'onceOff':
			//discount = 1;
			// weekly
			if ( $( "#col-weekly" ).hasClass( "on" ) ) {
				$( "#col-weekly" ).removeClass( "on" );
				document.getElementById("weekly").src = "https://www.moplovers.com.au/wp-content/uploads/2017/02/Weekly-off.png";
			}
			// fortnightly
			if ( $( "#col-fortnightly" ).hasClass( "on" ) ) {
				$( "#col-fortnightly" ).removeClass( "on" );
				document.getElementById("fortnightly").src = "https://www.moplovers.com.au/wp-content/uploads/2017/02/Fortnightly-off.png";
			}
			// monthly
			if ( $( "#col-monthly" ).hasClass( "on" ) ) {
				$( "#col-monthly" ).removeClass( "on" );
				document.getElementById("monthly").src = "https://www.moplovers.com.au/wp-content/uploads/2017/02/Monthly-off.png";
			}
			
break;
case 'weekly':
			//discount = 0.5;
			// Once Off
			if ( $( "#col-once-off" ).hasClass( "on" ) ) {
					$( "#col-once-off" ).removeClass( "on" );
					document.getElementById("once-off").src = "https://www.moplovers.com.au/wp-content/uploads/2017/02/Onceoff-off.png";
				}	
			// fortnightly
			if ( $( "#col-fortnightly" ).hasClass( "on" ) ) {
					$( "#col-fortnightly" ).removeClass( "on" );
					document.getElementById("fortnightly").src = "https://www.moplovers.com.au/wp-content/uploads/2017/02/Fortnightly-off.png";
				}
			// monthly
			if ( $( "#col-monthly" ).hasClass( "on" ) ) {
					$( "#col-monthly" ).removeClass( "on" );
					document.getElementById("monthly").src = "https://www.moplovers.com.au/wp-content/uploads/2017/02/Monthly-off.png";
				}
break;
case 'fortnightly':
			//discount = 0.45;
			// once-off
			if ( $( "#col-once-off" ).hasClass( "on" ) ) {
				$( "#col-once-off" ).removeClass( "on" );
				document.getElementById("once-off").src = "https://www.moplovers.com.au/wp-content/uploads/2017/02/Onceoff-off.png";
			}
			// weekly
			if ( $( "#col-weekly" ).hasClass( "on" ) ) {
				$( "#col-weekly" ).removeClass( "on" );
				document.getElementById("weekly").src = "https://www.moplovers.com.au/wp-content/uploads/2017/02/Weekly-off.png";
			}
			// monthly
			if ( $( "#col-monthly" ).hasClass( "on" ) ) {
				$( "#col-monthly" ).removeClass( "on" );
				document.getElementById("monthly").src = "https://www.moplovers.com.au/wp-content/uploads/2017/02/Monthly-off.png";
			}
break;
case 'monthly':
			//discount = 0.4;
			// once- off
			if ( $( "#col-once-off" ).hasClass( "on" ) ) {
				$( "#col-once-off" ).removeClass( "on" );
				document.getElementById("once-off").src = "https://www.moplovers.com.au/wp-content/uploads/2017/02/Onceoff-off.png";
			}
			// weekly
			if ( $( "#col-weekly" ).hasClass( "on" ) ) {
				$( "#col-weekly" ).removeClass( "on" );
				document.getElementById("weekly").src = "https://www.moplovers.com.au/wp-content/uploads/2017/02/Weekly-off.png";
			}
			// fortnightly
			if ( $( "#col-fortnightly" ).hasClass( "on" ) ) {
				$( "#col-fortnightly" ).removeClass( "on" );
				document.getElementById("fortnightly").src = "https://www.moplovers.com.au/wp-content/uploads/2017/02/Fortnightly-off.png";
			}
break;
	}
}
